clear;
tday(1,1)=20011012;
tday(2,1)=20011013;

mydatenum=tday2datenum(tday);

datestr(mydatenum)
