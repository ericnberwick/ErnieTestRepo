clear;

getFrontContract( 18, 1 )

getFrontContract( 20, 1 )

getFrontContract(18, 0)

getFrontContract(20, 0)
