clear;

assert(2==yyyymmdd2month(19250204));
assert(10==yyyymmdd2month(20051011));

