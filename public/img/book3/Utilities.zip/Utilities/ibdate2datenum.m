function [ myDatenum ] = ibdate2datenum( ibdate )
%[ myDatenum ] = ibdate2datenum( ibdate )
%   Convert IB date (long integer specifying the number of seconds since
%   1/1/1970 GMT) to Matlab datenum


end

