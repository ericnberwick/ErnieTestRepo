pair=getOffDiagPair(2);
assert(pair(1)==[1 2]);

pair=getOffDiagPair(3);
assert(pair(1)==[1 2] & pair(2)==[1 3] & pair(3)==[2 3]);

