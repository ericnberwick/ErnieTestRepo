clear;

assert(strcmp('Z9', getPrevContract('F0')));

assert(strcmp('H2', getPrevContract('J2')));

assert(strcmp('X9', getPrevContract('Z9')));