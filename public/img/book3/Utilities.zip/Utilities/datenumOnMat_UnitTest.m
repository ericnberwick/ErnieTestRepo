strarr=repmat({'20000101', '20010102'}, [2 1])

foo=datenumOnMat(strarr, 'yyyymmdd')

datestr(foo)
  
