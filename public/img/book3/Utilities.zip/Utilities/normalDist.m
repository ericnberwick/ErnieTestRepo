function [ N ] = normalDist(x)
%[ N ] = normalDist(x)

N=1/(2*pi)*exp(-x^2/2);

end

