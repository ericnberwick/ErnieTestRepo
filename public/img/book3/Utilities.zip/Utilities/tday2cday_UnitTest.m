clear;

tday=[20131129:20131206];

cday=tday2cday(tday)

tday=[20131129:20131206]';

cday=tday2cday(tday)
