clear;

assert(numWeekdaysTill(20120712, 20120716)==2);