function myRsi = RSI( cl, x )
%myRsi = RSI( cl, x )

myRsi=100-100./(1+RS(cl, x));
end

